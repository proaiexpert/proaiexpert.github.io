# ProAI Spline Runtime Bundle

Canonical Spline scene:
https://prod.spline.design/Ps48UZeUPJBLxiy2/scene.splinecode

This bundle preserves the exact public scene URL and a minimal Spline Runtime loader.

Important:
- The scene itself remains hosted by Spline at the URL above.
- The current ChatGPT execution sandbox cannot resolve `prod.spline.design`, so the remote binary `.splinecode`
  could not be fetched and rendered locally in this session.
- The loader code and project structure were generated and syntax-checked locally.
- On a normal internet-connected machine:
  1. `npm install`
  2. `npm run dev`
  3. open the localhost URL shown by Vite.
