import { Application } from '@splinetool/runtime';

const canvas = document.getElementById('canvas3d');
const app = new Application(canvas);

app.load('https://prod.spline.design/Ps48UZeUPJBLxiy2/scene.splinecode')
  .then(() => {
    console.log('Spline scene loaded');
    console.log('Objects:', app.getAllObjects?.() ?? 'getAllObjects unavailable');
  })
  .catch((error) => {
    console.error('Spline scene failed to load', error);
  });

window.splineApp = app;
